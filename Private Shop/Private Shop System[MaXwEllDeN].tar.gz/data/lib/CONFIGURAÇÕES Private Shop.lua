-- ########################################################
-- #####        Name: Private Shop System             #####
-- #####        Version: 2.0                          #####
-- ########################################################
-- #####  Developed by Maxwell Alcantara[MaXwEllDeN]  #####
-- #####  Contact: maxwellmda@gmail.com               #####
-- #####           maxwellden@hotmail.com             #####
-- ########################################################

_PV_SHOP_CONFIG ={
   premmy = false,
   level = 1,
   maxitens = 10,
   notadd = {2160, 2152, 2148},
   prefix_shop = true, -- Prefixo [Shop] antes do nome do player?
}
